const Restaurants = require("./Restaurants.js");
const Dishes = require("./Dishes.js");
const Testcollections = require("./Testcollections.js");
const Orders = require("./Orders.js");
const Users = require("./Users.js");

module.exports = { Restaurants, Dishes, Testcollections };
